package com.example.feedon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class AdminOption extends AppCompatActivity {

    RadioButton rb1,rb2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_option);
    }
    public void Registration(View v)
    {
        rb1=(RadioButton)findViewById(R.id.rb1);
        Intent i=new Intent(AdminOption.this,RegisterFaculty.class);
        startActivity(i);
    }
    public void Feedback(View v)
    {
        rb2=(RadioButton)findViewById(R.id.rb2);
        Intent i=new Intent(AdminOption.this,ViewFeedback.class);
        startActivity(i);
    }
}
