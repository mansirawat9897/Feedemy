package com.example.feedon;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterStudent extends AppCompatActivity {
     TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    TextView tv5;
    EditText et1;
    EditText et2;
    Spinner sp1;
    Spinner sp2;
    Spinner sp3;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_student);
        tv1=(TextView)findViewById(R.id.tv1);
        tv2=(TextView)findViewById(R.id.tv2);
        tv3=(TextView)findViewById(R.id.tv3);
        tv4=(TextView)findViewById(R.id.tv4);
        tv5=(TextView)findViewById(R.id.tv5);
        et1=(EditText)findViewById(R.id.et1);
        et2=(EditText)findViewById(R.id.et2);
        Spinner sp1=(Spinner)findViewById(R.id.sp1);
        sp2=(Spinner)findViewById(R.id.sp2);
        sp3=(Spinner)findViewById(R.id.sp3);
        b1=(Button)findViewById(R.id.button);
        String Department[] = getResources().getStringArray(R.array.Department);
        System.out.println("array dept is "+Department);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Department, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        sp1.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.Course, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp2.setAdapter(adapter1);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.Semester, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp3.setAdapter(adapter2);

    }
    public void Register(View v)
    {
        sp1=(Spinner)findViewById(R.id.sp1);
        sp2=(Spinner)findViewById(R.id.sp2);
        sp3=(Spinner)findViewById(R.id.sp3);

       if((et1.getText().toString().equals(""))||(sp1.getSelectedItem().toString().equals(""))||(sp2.getSelectedItem().toString().equals(""))||(sp3.getSelectedItem().toString().equals(""))||(et2.getText().toString().equals("")))
        {
            System.out.println("valuuuuuuuuuuuuuuuuuuuuuu is "+et2.getText());
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
        }
        else {
           String num = (String.valueOf(et1.getText()));
           if (num.length() == 8) {
               SQLiteDatabase sqdb;
               sqdb = openOrCreateDatabase("RegisterStudent.db", MODE_PRIVATE, null);
               String qry = "create table if not exists Registersy(StudentId varchar primary key,Department varchar not null,Course varchar not null,Semester integer not null,Password varchar not null);";
               sqdb.execSQL(qry);
               Toast.makeText(this, "Table created", Toast.LENGTH_LONG).show();


               try {
                   String StudentId = String.valueOf(et1.getText());
                   String Department = String.valueOf(sp1.getSelectedItem());
                   String Course = String.valueOf(sp2.getSelectedItem());
                   String Semester = String.valueOf(sp3.getSelectedItem());
                   String Password = String.valueOf(et2.getText());


                   String num1 = et1.getText().toString();
                   System.out.println("num1 is" + num1);
                   String Query = "select * from Registersy where StudentId= '" + num1 + "'";

                   sqdb.execSQL(Query);
                   System.out.println("select query" + Query);
                   Cursor cursor = sqdb.rawQuery(Query, null);
                   int cnt = cursor.getCount();
                   if (cnt > 0) {
                       Toast.makeText(this, "Student Id already exists", Toast.LENGTH_LONG).show();
                   } else {
                       String qry1 = "insert into Registersy values('" + StudentId + "','" + Department + "','" + Course + "','" + Semester + "','" + Password + "');";
                       System.out.println("Execution");
                       sqdb.execSQL(qry1);
                       Toast.makeText(this, "Registered successfully", Toast.LENGTH_LONG).show();
                       et1.setText("");
                       sp1.setAdapter(null);
                       sp2.setAdapter(null);
                       sp3.setAdapter(null);
                       et2.setText("");

                   }


               } catch (NullPointerException e) {
                   System.out.println("Problem is due to" + e.getMessage());
               }
           }
       }      }
    }

