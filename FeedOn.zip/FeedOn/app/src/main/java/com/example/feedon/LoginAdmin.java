package com.example.feedon;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginAdmin extends AppCompatActivity {
    EditText et1;
    EditText et2;
    TextView tv1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);
    }

    public void LoginAdmin(View v)
    {
        b1=(Button)findViewById(R.id.b1);
        et1=(EditText)findViewById(R.id.et1);
        et2=(EditText)findViewById(R.id.et2);
        tv1=(TextView)findViewById(R.id.tv1);
        String userid=String.valueOf(et1.getText());
        String password=String.valueOf(et2.getText());
        if(userid.equals("Admin")&&(password.equals("admin"))) {
            Toast.makeText(this,"Login successfully",Toast.LENGTH_LONG).show();
            Intent i = new Intent(LoginAdmin.this, AdminOption.class);
            startActivity(i);
        }
        else
        {
            Toast.makeText(this,"Enter valid userid and password",Toast.LENGTH_LONG).show();
        }
    }

}
