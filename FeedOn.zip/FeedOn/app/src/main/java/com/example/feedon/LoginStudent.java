package com.example.feedon;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginStudent extends AppCompatActivity {
    TextView tv1;
    TextView tv2;
    EditText et1;
    EditText et2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_student);
    }
    public void login(View v)
    {
        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        et1 = (EditText) findViewById(R.id.et1);
        et2 = (EditText) findViewById(R.id.et2);
        b1 = (Button) findViewById(R.id.b1);
        SQLiteDatabase sqdb;
        sqdb=openOrCreateDatabase("RegisterStudent.db",MODE_PRIVATE,null);
        String qry = "create table if not exists Registersy(StudentId varchar primary key,Department varchar not null,Course varchar not null,Semester integer not null,Password varchar not null);";
        sqdb.execSQL(qry);
        String tablename="Registersy";
        String Dbfield="StudentId";
        String num=String.valueOf(et1.getText());
        try {
            System.out.println("Try block");
            String Query = "Select StudentId from " + tablename + " where " + Dbfield + " = '" + num + "';";
            System.out.println("check query" + Query);
            Cursor c = sqdb.rawQuery(Query, null);
            int flag = 0;
            if(c.getCount()<= 0)
            {
                int cu=c.getCount();
                System.out.println("count is"+cu);
                c.close();
                flag = 1;
            }
            else
            {

                if (flag == 0)
                {
                    Toast.makeText(this, "Login successfully", Toast.LENGTH_LONG).show();
                    Intent ii = new Intent(this, Feedback.class);
                    startActivity(ii);
                }
               else
                {
                    Toast.makeText(this, "Incorrect data", Toast.LENGTH_LONG).show();
                }

        }}
        catch (Exception e) {
            System.out.println("Problem is due to" + e.getMessage());
        }


    }
}
